package com.example.flutter_application_mobiletest2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
