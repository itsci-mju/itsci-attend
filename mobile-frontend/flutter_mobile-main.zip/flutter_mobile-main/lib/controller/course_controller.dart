import 'dart:convert';
import 'package:flutter_application_mobiletest2/model/course.dart';
import 'package:flutter_application_mobiletest2/model/subject.dart';
import 'package:flutter_application_mobiletest2/ws_config.dart';
import 'package:http/http.dart' as http;

import '../model/user.dart';

class CourseController {
  Future listAllCourse() async {
    var url = Uri.parse(baseURL + '/course/list');
    http.Response response = await http.get(url);
    final utf8Body = utf8.decode(response.bodyBytes);
    List<dynamic> jsonResponse = json.decode(utf8Body);
    List<Course> list =
        jsonResponse.map((e) => Course.formJsonToCourse(e)).toList();
    //print(list);
    return list;
  }

  Future listCoursesByUserId(String IdUser) async {
    var url = Uri.parse(baseURL + '/course/listbyiduser/' + IdUser);
    http.Response response = await http.get(url);
    final utf8Body = utf8.decode(response.bodyBytes);
    List<dynamic> jsonResponse = json.decode(utf8Body);
    List<Course> list =
        jsonResponse.map((e) => Course.formJsonToCourse(e)).toList();
    print(list);
    return list;
  }

  Future get_Course(String id) async {
    var url = Uri.parse(baseURL + '/course/getbyid/' + id);
    http.Response response = await http.get(url);
    final utf8Body = utf8.decode(response.bodyBytes);
    var jsonResponse = json.decode(utf8Body);
    Course course = Course.formJsonToCourse(jsonResponse);
    return course;
  }

  Future deleteCourse(String id) async {
    var url = Uri.parse(baseURL + "/course/delete/" + id);
    http.Response response = await http.delete(url);
    return response;
  }

  Future addCourse(
      String subjectId, String userId, String term, String semester) async {
    Map data = {
      "subjectId": subjectId,
      "userId": userId,
      "term": term,
      "semester": semester,
    };
    var jsonData = json.encode(data);
    var url = Uri.parse(baseURL + "/course/add");
    http.Response response =
        await http.post(url, headers: headers, body: jsonData);
    print(response.body);
    return response;
  }

  Future updateCourse(String id, String subjectId, String userId, String term,
      String semester) async {
    Map data = {
      "id": id,
      "subjectId": subjectId,
      "userId": userId,
      "term": term,
      "semester": semester,
    };
    var jsonData = json.encode(data);
    var url = Uri.parse(baseURL + "/course/update");
    http.Response response =
        await http.put(url, headers: headers, body: jsonData);
    print(response.body);
    return response;
  }
}
