import 'package:flutter/material.dart';

var kMyAppBar = AppBar(
  title: Image.asset('images/mju_logo_main-resize.png'),
  toolbarHeight: 120,
  backgroundColor: Colors.white,
  elevation: 10,
);
